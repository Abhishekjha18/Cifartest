# -*- coding: utf-8 -*-
"""
High-level CRVQ orchestrator  –  verbose/debug edition
"""

import logging
import numpy as np
import torch
from torch import nn
from modules_debug import (partition_to_vectors, reassemble_from_vectors,
                           compute_importance_fc, reorder_columns,
                           kmeans_codebook, vector_quantize,
                           fine_tune_codebooks, beam_search_optimize,
                           quant_loss, fine_tune_block, e2e_fine_tune)

log = logging.getLogger("CRVQ.core")


class CRVQ:
    def __init__(self, e=8, m=4, lam=0.05, d=8, eps=1e-2):
        self.e = e
        self.K = 2 ** e
        self.m = m
        self.lam = lam
        self.d = d
        self.eps = eps
        self.state = {}

    # --------------------------------------------------------------------- #
    #  Hessian proxy capture
    # --------------------------------------------------------------------- #
    def _capture_hessian_diag(self, model, loader):
        h_diag = {}
        hooks = []

        def mk(name):
            def _hook(mod, inp, _out):
                x = inp[0].detach()
                if x.dim() > 2:
                    x = x.flatten(0, -2)
                h = x.t() @ x
                h_diag[name] = h_diag.get(name, 0) + h
            return _hook

        for n, m in model.named_modules():
            if isinstance(m, nn.Linear):
                hooks.append(m.register_forward_hook(mk(n)))
        model.eval()
        with torch.no_grad():
            for xb, _ in loader:
                model(xb)
        for h in hooks:
            h.remove()

        inv = {}
        for n, mat in h_diag.items():
            diag = torch.diag(torch.inverse(mat + 1e-6 * torch.eye(mat.size(0))))
            inv[n] = diag.cpu().numpy()
        return inv

    # --------------------------------------------------------------------- #
    #  Main quant loop
    # --------------------------------------------------------------------- #
    def quantise(self, model, calib_loader, ft_loader=None):
        h_inv = self._capture_hessian_diag(model, calib_loader)

        for name, layer in model.named_modules():
            if not isinstance(layer, nn.Linear):
                continue
            W = layer.weight.data.clone()
            out_dim, in_dim = W.shape
            log.info(f"[{name}]  out={out_dim} in={in_dim}")

            # Pre-VQ (for error) ---------------------
            vec, pad = partition_to_vectors(W.cpu().numpy(), self.d)
            C_pre = kmeans_codebook(vec, self.K)
            vec_q, _ = vector_quantize(vec, C_pre)
            Wq_pre = torch.tensor(reassemble_from_vectors(vec_q, out_dim, in_dim,
                                                          pad, self.d),
                                  dtype=W.dtype)
            # Importance & reorder -------------------
            imp = compute_importance_fc(W, Wq_pre, h_inv[name])
            W_sorted, perm = reorder_columns(W, imp)

            # Base codebook --------------------------
            V_s_np, pad = partition_to_vectors(W_sorted.cpu().numpy(), self.d)
            C_base = kmeans_codebook(V_s_np, self.K)
            Vq_s_np, codes_base = vector_quantize(V_s_np, C_base)
            Wq_sorted = torch.tensor(reassemble_from_vectors(Vq_s_np, out_dim,
                                                             in_dim, pad, self.d),
                                     dtype=W.dtype)

            # Extended codebooks ---------------------
            crit = max(1, int(self.lam * in_dim))
            C_ext, codes_ext = [], []
            Wenc = Wq_sorted.clone()
            for t in range(self.m - 1):
                resid = (W_sorted[:, :crit] - Wenc[:, :crit]).cpu().numpy()
                Vr_np, p_r = partition_to_vectors(resid, self.d)
                Ce = kmeans_codebook(Vr_np, self.K)
                Vqe, ce = vector_quantize(Vr_np, Ce)
                Wenc[:, :crit] += torch.tensor(
                    reassemble_from_vectors(Vqe, out_dim, crit, p_r, self.d),
                    dtype=W.dtype)
                C_ext.append(Ce)
                codes_ext.append(ce)

            # Fine-tune / beam search -----------------
            loss0 = quant_loss(W_sorted, Wenc)
            log.info(f"  init loss={loss0:.3e}")
            if loss0 > self.eps:
                C_base, C_ext = fine_tune_codebooks(C_base, C_ext,
                                                    torch.tensor(V_s_np), codes_base,
                                                    codes_ext, None)
                all_codes = beam_search_optimize(V_s_np, [C_base]+C_ext,
                                                 [codes_base]+codes_ext)
                codes_base = all_codes[0]; codes_ext = all_codes[1:]

            # Reconstruct full Wq in original order ---
            vec_all = C_base[codes_base]
            for Ce, ce in zip(C_ext, codes_ext):
                vec_all += Ce[ce]
            Wq_sorted_np = reassemble_from_vectors(vec_all, out_dim, in_dim,
                                                   pad, self.d)
            Wq_final = torch.tensor(Wq_sorted_np[:, np.argsort(perm)],
                                    dtype=W.dtype)
            layer.weight.data.copy_(Wq_final)

            # store state
            self.state[name] = dict(C_base=C_base, C_ext=C_ext,
                                    codes_base=codes_base, codes_ext=codes_ext,
                                    perm=perm)
            log.info(f"  done layer. Final Frobenius diff="
                     f"{torch.norm(W - Wq_final):.3e}")

        # Optional block+E2E
        if ft_loader is not None:
            fclayers = [m for m in model.modules() if isinstance(m, nn.Linear)]
            fine_tune_block(model, fclayers, ft_loader, epochs=1)
            e2e_fine_tune(model, ft_loader, epochs=1)
        return model
