# -*- coding: utf-8 -*-
"""
CRVQ helpers  –  verbose/debug version
"""

import logging
import numpy as np
import torch
from sklearn.cluster import KMeans

log = logging.getLogger("CRVQ.modules")

# ------------------------------------------------------------------------- #
#  Partition / Reassemble
# ------------------------------------------------------------------------- #
def partition_to_vectors(mat: np.ndarray, d: int):
    out, inp = mat.shape          # [out, in]
    flat = mat.T.reshape(-1)      # column-major
    pad_len = (-len(flat)) % d
    if pad_len:
        log.debug(f" pad {pad_len} zeros to make len(flat) % d == 0")
        flat = np.concatenate([flat, np.zeros(pad_len, flat.dtype)])
    vectors = flat.reshape(-1, d)
    log.debug(f" partition: mat {mat.shape} -> vectors {vectors.shape}")
    return vectors, pad_len


def reassemble_from_vectors(vectors: np.ndarray,
                            out_dim: int, in_dim: int,
                            pad: int, d: int):
    flat = vectors.reshape(-1)
    if pad:
        flat = flat[:-pad]
    mat_sorted = flat.reshape(in_dim, out_dim).T
    log.debug(f" reassemble: vectors {vectors.shape} -> mat_sorted {mat_sorted.shape}")
    return mat_sorted


# ------------------------------------------------------------------------- #
#  Importance & Reordering
# ------------------------------------------------------------------------- #
def compute_importance_fc(W: torch.Tensor,
                          Wq: torch.Tensor,
                          h_inv_diag: np.ndarray):
    diff2 = (W - Wq).square().cpu().numpy()   # [out, in]
    max_err2 = diff2.max(0)                   # (in,)
    if len(h_inv_diag) != len(max_err2):
        log.warning("   H-diag len mismatches in_features – fallback to unweighted.")
        h_inv_diag = np.ones_like(max_err2)
    importance = 0.5 * max_err2 * h_inv_diag
    log.debug(f" importance: max_err2 {max_err2.shape}")
    return importance


def reorder_columns(W: torch.Tensor, importance: np.ndarray):
    sort_idx = np.argsort(-importance)
    W_sorted = W[:, sort_idx]
    log.debug(f" reorder: sort_idx len={len(sort_idx)}  W -> {W_sorted.shape}")
    return W_sorted, sort_idx


# ------------------------------------------------------------------------- #
#  K-Means Codebook + VQ
# ------------------------------------------------------------------------- #
def kmeans_codebook(vectors: np.ndarray, k: int, seed=0):
    k_eff = min(k, len(vectors))
    if k_eff < k:
        log.warning(" kmeans: fewer samples than centroids; centroids will repeat.")
    km = KMeans(n_clusters=k_eff, n_init=5, random_state=seed)
    km.fit(vectors)
    C = km.cluster_centers_
    if C.shape[0] < k:
        pad = np.zeros((k - C.shape[0], C.shape[1]), C.dtype)
        C = np.vstack([C, pad])
    log.debug(f" kmeans: centroids {C.shape}")
    return C


def vector_quantize(vectors: np.ndarray, codebook: np.ndarray):
    diff = vectors[:, None, :] - codebook[None, :, :]
    dist2 = (diff ** 2).sum(-1)
    codes = dist2.argmin(-1)
    quant = codebook[codes]
    return quant, codes


# ------------------------------------------------------------------------- #
#  Fine-tuning / Beam search (unchanged – but with logs)
# ------------------------------------------------------------------------- #
def fine_tune_codebooks(C_base, C_exts,
                        vectors_sorted,
                        codes_base, codes_exts,
                        X_cols,
                        lr=1e-3, steps=30):
    import torch
    dev = vectors_sorted.device
    log.info("  FT-codebook: gradient descent on centroids …")
    Cb = torch.tensor(C_base, device=dev, requires_grad=True)
    Cext = [torch.tensor(C, device=dev, requires_grad=True) for C in C_exts]
    opt = torch.optim.Adam([Cb] + Cext, lr=lr)
    cb_idx = torch.tensor(codes_base, device=dev)
    ext_idx = [torch.tensor(c, device=dev) for c in codes_exts]

    for it in range(steps):
        opt.zero_grad()
        vq = Cb[cb_idx]
        for Ce, ci in zip(Cext, ext_idx):
            vq = vq + Ce[ci]
        loss = (vq - vectors_sorted).pow(2).mean()
        loss.backward()
        opt.step()
        if it % 10 == 0:
            log.debug(f"   step={it:3d}  VQ-MSE={loss.item():.4e}")
    return (Cb.detach().cpu().numpy(),
            [C.detach().cpu().numpy() for C in Cext])


def beam_search_optimize(vectors, codebooks, init_codes, beam=4):
    log.info("  Beam search over code indices …")
    codes_out = [c.copy() for c in init_codes]
    accum = sum(C[c] for C, c in zip(codebooks, codes_out))
    err = ((vectors - accum) ** 2).sum(1)

    for b_i, (C, cvec) in enumerate(zip(codebooks, codes_out)):
        for i in range(len(cvec)):
            best = cvec[i]
            best_err = err[i]
            cand = np.argpartition(((vectors[i] - (accum[i] - C[cvec[i]] + C))**2).sum(1), beam)[:beam]
            for alt in cand:
                delta = accum[i] - C[cvec[i]] + C[alt]
                e = ((vectors[i] - delta) ** 2).sum()
                if e < best_err:
                    best_err, best = e, alt
            if best != cvec[i]:
                accum[i] = accum[i] - C[cvec[i]] + C[best]
                err[i] = best_err
                cvec[i] = best
    return codes_out


# ------------------------------------------------------------------------- #
#  Loss / Block-FT / E2E-FT  (same as previously, with log statements)
# ------------------------------------------------------------------------- #
def quant_loss(W, Wq, X=None):
    if X is None:
        return torch.norm(W - Wq).item()
    return torch.norm(W @ X - Wq @ X).item()


def fine_tune_block(model, layers, loader, lr=1e-3, epochs=1):
    from torch import nn
    log.info("  Block-FT …")
    for p in model.parameters():
        p.requires_grad = False
    for ly in layers:
        for p in ly.parameters():
            p.requires_grad = True
    opt = torch.optim.Adam([p for ly in layers for p in ly.parameters()], lr=lr)
    ce = nn.CrossEntropyLoss()
    for ep in range(epochs):
        for xb, yb in loader:
            opt.zero_grad()
            ce(model(xb), yb).backward()
            opt.step()
    for ly in layers:
        for p in ly.parameters():
            p.requires_grad = False


def e2e_fine_tune(model, loader, lr=1e-4, epochs=1):
    from torch import nn
    log.info("  E2E-FT …")
    for p in model.parameters():
        p.requires_grad = True
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    ce = nn.CrossEntropyLoss()
    for ep in range(epochs):
        for xb, yb in loader:
            opt.zero_grad()
            ce(model(xb), yb).backward()
            opt.step()
    for p in model.parameters():
        p.requires_grad = False
