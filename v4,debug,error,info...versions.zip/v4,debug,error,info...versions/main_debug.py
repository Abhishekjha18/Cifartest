import os, logging
# Set default log level here; environment variable overrides can change it.
os.environ.setdefault("LOGLEVEL", "DEBUG")  #  DEBUG | INFO | WARNING | ERROR | CRITICAL
logging.basicConfig(level=os.environ["LOGLEVEL"],
                    format="%(levelname)s %(name)s: %(message)s")

import torch
from torch import nn
from torchvision import datasets, transforms
from torch.utils.data import DataLoader
from crvq_debug import CRVQ


# ---------- Model -------------------------------------------------------- #
class SimpleCNN(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(1, 16, 3, 1), nn.ReLU(),
            nn.MaxPool2d(2),
            nn.Conv2d(16, 32, 3, 1), nn.ReLU(),
            nn.MaxPool2d(2),
        )
        self.fc1 = nn.Linear(32 * 5 * 5, 128)
        self.fc2 = nn.Linear(128, 10)

    def forward(self, x):
        x = self.conv(x)
        x = x.flatten(1)
        x = torch.relu(self.fc1(x))
        return self.fc2(x)


# ---------- Data --------------------------------------------------------- #
tfm = transforms.ToTensor()
test_ds  = datasets.MNIST("./data", train=False, download=True, transform=tfm)
test_ld  = DataLoader(test_ds, batch_size=256)
calib_ld = DataLoader(test_ds, batch_size=256)   # reuse test set for demo


# ---------- Load baseline ------------------------------------------------ #
model = SimpleCNN()
model.load_state_dict(torch.load("original_model.pth"))
model.eval()


def acc(net):
    net.eval()
    tot = 0
    with torch.no_grad():
        for xb, yb in test_ld:
            tot += (net(xb).argmax(1) == yb).sum().item()
    return tot / len(test_ds)


print(f"Baseline accuracy: {acc(model):.4f}")

# ---------- CRVQ --------------------------------------------------------- #
quant = CRVQ(e=8, m=4, lam=0.05, d=8)
model_q = quant.quantise(model, calib_ld, ft_loader=calib_ld)
print(f"Quantised accuracy: {acc(model_q):.4f}")

# Compression for FC only
orig_bits = sum(p.numel()*32 for n,p in model.named_parameters()
                if "fc" in n and "weight" in n)
q_bits = sum(p.numel()*8 for n,p in model_q.named_parameters()
             if "fc" in n and "weight" in n)
print(f"Approx FC compression: {(orig_bits/q_bits):.2f}×")

torch.save(model_q.state_dict(), "quantized_model.pth")
print("Saved quantized_model.pth")
