import torch
import numpy as np
from modules import (
    Prequantize, ComputeImportance, ReorderChannels,
    KMeansCodebook, VectorQuant, ComputeError, Update,
    FineTuneCodebook, BeamSearchOptimize, FineTuneBlock, E2E_FineTune
)

class CRVQ:
    def __init__(self, m: int = 4, lambda_ratio: float = 0.02,
                 e_bit: int = 8, d_dim: int = 8, loss_threshold: float = 1e-2):
        """
        m: total codebooks (1 base + m-1 extended),
        lambda_ratio: fraction of channels to treat as critical,
        e_bit: codebook bit-width,
        d_dim: sub-vector dimension,
        loss_threshold: convergence threshold on quant loss.
        """
        self.m = m
        self.lambda_ratio = lambda_ratio
        self.e_bit = e_bit
        self.d_dim = d_dim
        self.loss_threshold = loss_threshold
        # will fill per-layer hessian inverse diagonals
        self.hessian_inv = {}

    def compute_hessian_inv(self, model, calib_loader):
        # hook-based accumulation
        stats = {}
        for name, layer in model.named_modules():
            if isinstance(layer, torch.nn.Linear):
                dim = layer.weight.shape[1]
                stats[layer] = {'XTX': torch.zeros(dim, dim), 'count': 0}
                def hook(mod, inp, out, key=layer):
                    X = inp[0].detach()
                    if X.dim() > 2:
                        X = X.reshape(-1, X.shape[-1])
                    stats[key]['XTX'] += X.t() @ X
                    stats[key]['count'] += X.shape[0]
                layer.register_forward_hook(hook)
        model.eval()
        with torch.no_grad():
            for X, _ in calib_loader:
                model(X)
        # invert
        for layer, st in stats.items():
            XTX = st['XTX'] + 1e-6 * torch.eye(st['XTX'].size(0))
            try:
                inv = torch.inverse(XTX)
            except RuntimeError:
                inv = torch.linalg.pinv(XTX)
            self.hessian_inv[layer] = inv.diag().cpu().numpy()

    def quantize_model(self, model, calib_loader):
        # Step 0: compute Hessian proxy
        self.compute_hessian_inv(model, calib_loader)
        # extract one batch for codebook fine-tuning / beam-search
        X_calib, _ = next(iter(calib_loader))
        X_calib = X_calib.reshape(-1, X_calib.shape[-1]).T.cpu().numpy()

        for name, layer in model.named_modules():
            if not isinstance(layer, torch.nn.Linear):
                continue
            W = layer.weight.data.cpu().numpy()  # [out, in]
            H_inv_diag = self.hessian_inv[layer] # [in]

            # 1) Prequantize
            W_pre, C_base = Prequantize(W, self.e_bit, self.d_dim)

            # 2) Importance & reorder
            imp = ComputeImportance(W, W_pre, H_inv_diag)
            W_sorted, sorted_idx = ReorderChannels(W, imp)

            # 3) Base codebook on sorted W
            out_dim, in_dim = W_sorted.shape
            pad = (self.d_dim - (in_dim % self.d_dim)) % self.d_dim
            W_pad = np.pad(W_sorted, ((0,0),(0,pad)), mode='constant')
            vects = W_pad.T.reshape(-1, self.d_dim)
            C_base = KMeansCodebook(vects, self.e_bit)
            Wbase_q, B_base = VectorQuant(vects, C_base)
            Wbase_q = Wbase_q.reshape(in_dim+pad, out_dim).T[:, :in_dim]

            # 4) Extended codebooks
            C_exts, B_exts = [], []
            num_crit = max(1, int(in_dim * self.lambda_ratio))
            W_enc = Wbase_q.copy()
            crit_vectors = W_enc[:, :num_crit].T.reshape(-1, self.d_dim)
            for t in range(1, self.m):
                Cext = KMeansCodebook(crit_vectors, self.e_bit)
                Wext_q, Bext = VectorQuant(crit_vectors, Cext)
                Wext_q = Wext_q.reshape(num_crit, out_dim).T
                W_enc[:, :num_crit] = Update(W_enc[:, :num_crit], Wext_q)
                C_exts.append(Cext)
                B_exts.append(Bext)
                # recompute residual
                crit_vectors = (W_sorted[:, :num_crit] - W_enc[:, :num_crit]).T.reshape(-1, self.d_dim)

            # 5) FineTune codebooks
            C_base, C_exts = FineTuneCodebook(
                C_base, C_exts, W_sorted, B_base, B_exts, X_calib
            )

            # 6) Beam-search refine codes
            B_base, B_exts = BeamSearchOptimize(
                W_sorted, C_base, C_exts, B_base, B_exts, X_calib
            )

            # 7) Reconstruct final quantized weight
            from modules import reconstruct_weight
            W_q = reconstruct_weight(
                C_base, C_exts, B_base, B_exts,
                sorted_idx, layer.weight.shape, layer.weight.dtype
            )
            layer.weight.data.copy_(torch.from_numpy(W_q))

            # 8) FineTune block (this single linear layer as a 'block')
            FineTuneBlock(model, [layer], calib_loader)

        # 9) End-to-end fine-tuning
        E2E_FineTune(model, calib_loader)
        return model

    def save_quant_state(self, path):
        torch.save({
            'hessian_inv': self.hessian_inv,
            'params': (self.m, self.lambda_ratio, self.e_bit, self.d_dim)
        }, path)

    def load_quant_state(self, path):
        ckpt = torch.load(path)
        self.hessian_inv = ckpt['hessian_inv']
        (self.m, self.lambda_ratio, self.e_bit, self.d_dim) = ckpt['params']
