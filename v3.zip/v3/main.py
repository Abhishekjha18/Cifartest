import os, torch
from torch import nn
from torch.utils.data import DataLoader
from torchvision.datasets import MNIST
from torchvision.transforms import ToTensor
from crvq import CRVQ

class SimpleCNN(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv1 = nn.Conv2d(1,16,3,1)
        self.conv2 = nn.Conv2d(16,32,3,1)
        self.flat  = nn.Flatten()
        self.fc1   = nn.Linear(32*24*24,128)
        self.fc2   = nn.Linear(128,10)
    def forward(self,x):
        x=torch.relu(self.conv1(x))
        x=torch.relu(self.conv2(x))
        x=self.flat(x)
        x=torch.relu(self.fc1(x))
        return self.fc2(x)

def evaluate(model,loader):
    model.eval(); c=t=0
    with torch.no_grad():
        for X,y in loader:
            p = model(X).argmax(1);
            c += (p==y).sum().item(); t += y.size(0)
    return c/t

if __name__=='__main__':
    test_ds = MNIST('.',train=False,download=True,transform=ToTensor())
    test_loader = DataLoader(test_ds,batch_size=256,shuffle=False)
    calib_loader= DataLoader(test_ds,batch_size=512,shuffle=True)

    model = SimpleCNN()
    if os.path.exists('original_model.pth'):
        model.load_state_dict(torch.load('original_model.pth'))
        print('Loaded pretrained model.')
    else:
        raise FileNotFoundError('original_model.pth not found. Train & save baseline first.')

    acc_orig = evaluate(model,test_loader)
    print(f'Original accuracy : {acc_orig:.4f}')

    crvq = CRVQ(m=4,lambda_ratio=0.05,e_bit=8,d_dim=8)
    print('Running CRVQ…')
    qmodel = crvq.quantize_model(model, calib_loader)
    acc_q = evaluate(qmodel,test_loader)
    print(f'Quantised accuracy: {acc_q:.4f}')

    torch.save(qmodel.state_dict(),'quantized_model.pth')
    print('Saved quantized_model.pth')

    # compression stats
    conv_params = sum(p.numel() for n,p in qmodel.named_parameters() if 'conv' in n)
    fc_params   = sum(p.numel() for n,p in qmodel.named_parameters() if 'fc' in n)
    orig_bits   = (conv_params+fc_params)*32
    quant_bits  = conv_params*32 + fc_params*8  # only FC at 8‑bit
    print(f'Compression ratio : {orig_bits/quant_bits:.2f}×  (approx\u2020)')
