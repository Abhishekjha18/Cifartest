import numpy as np
import torch
from sklearn.cluster import KMeans

def Prequantize(W_np: np.ndarray, e_bit_width: int = 8, d_vector_dim: int = 8) -> (np.ndarray, np.ndarray):
    """
    Pre-quantizes the weight matrix W using a basic vector quantization.
    Returns quantized W and the base codebook.
    """
    # Flatten each COLUMN into d-dimensional vectors
    out_dim, in_dim = W_np.shape
    pad = (d_vector_dim - (out_dim % d_vector_dim)) % d_vector_dim
    W_pad = np.pad(W_np, ((0, pad), (0, 0)), mode='constant')
    vectors = W_pad.reshape(-1, d_vector_dim)  # (num_vectors, d)
    C_base = KMeansCodebook(vectors, e_bit_width)
    quantized_vecs, _ = VectorQuant(vectors, C_base)
    # Reassemble
    Wq_pad = quantized_vecs.reshape(W_pad.shape)
    Wq = Wq_pad[:out_dim, :]
    return Wq, C_base

def ComputeImportance(W: np.ndarray, W_quant: np.ndarray, H_inv_diag: np.ndarray) -> np.ndarray:
    """
    Computes channel importance for a FC layer: column-wise.
    I_i = 0.5 * max_j (W[j,i] - Wq[j,i])^2 * H_inv_diag[i]
    """
    diff2 = (W - W_quant) ** 2       # [out, in]
    max_err2 = diff2.max(axis=0)     # per column/channel
    importance = 0.5 * max_err2 * H_inv_diag
    return importance                # shape [in]

def ReorderChannels(W: np.ndarray, importance: np.ndarray) -> (np.ndarray, np.ndarray):
    """
    Reorders columns by descending importance.
    Returns W_sorted and the permutation indices.
    """
    sort_idx = np.argsort(-importance)
    W_sorted = W[:, sort_idx]
    return W_sorted, sort_idx

def KMeansCodebook(vectors: np.ndarray, e_bit_width: int) -> np.ndarray:
    """
    Learns a codebook of size 2^e_bit_width via KMeans.
    """
    n_clusters = 2 ** e_bit_width
    if vectors.size == 0 or n_clusters < 1:
        return np.zeros((n_clusters, vectors.shape[1]), dtype=vectors.dtype)
    n_clusters = min(n_clusters, vectors.shape[0])
    kmeans = KMeans(n_clusters=n_clusters, random_state=0, n_init='auto')
    kmeans.fit(vectors)
    centers = kmeans.cluster_centers_.astype(vectors.dtype)
    # pad if needed
    if centers.shape[0] < 2**e_bit_width:
        pad = np.zeros((2**e_bit_width - centers.shape[0], centers.shape[1]), dtype=vectors.dtype)
        centers = np.vstack([centers, pad])
    return centers

def VectorQuant(vectors: np.ndarray, codebook: np.ndarray) -> (np.ndarray, np.ndarray):
    """
    Quantizes each vector to its nearest codebook centroid.
    Returns quantized vectors and their codes.
    """
    if codebook.size == 0 or vectors.size == 0:
        return vectors, np.zeros(vectors.shape[0], dtype=int)
    # distance [n, k]
    diff = vectors[:, None, :] - codebook[None, :, :]
    dist2 = np.sum(diff * diff, axis=2)
    codes = np.argmin(dist2, axis=1)
    quantized = codebook[codes]
    return quantized, codes

def ComputeError(W: np.ndarray, W_encoded: np.ndarray) -> np.ndarray:
    """Residual error between original and quantized weights."""
    return W - W_encoded

def Update(W_encoded: np.ndarray, Et_encoded: np.ndarray) -> np.ndarray:
    """Additively updates quantized weights with residual quantization."""
    return W_encoded + Et_encoded

def QuantLoss(W_original: np.ndarray, W_encoded: np.ndarray, X: np.ndarray) -> float:
    """
    Quantization loss: ||W X - W_encoded X||^2_2
    X shape: [in, batch]
    W shape: [out, in]
    """
    WX = W_original.dot(X)
    WQX = W_encoded.dot(X)
    return float(np.linalg.norm(WX - WQX) ** 2)

# ---- Placeholder implementations replaced by actual code ----

def FineTuneCodebook(C_base, C_exts, W, B_base, B_exts, X_calib, lr=1e-4, steps=10):
    """
    Fine-tunes the base and extended codebooks via gradient-based optimization.
    """
    # Convert to torch
    Cb = torch.tensor(C_base, requires_grad=True)
    Ce_list = [torch.tensor(C, requires_grad=True) for C in C_exts]
    W_t = torch.tensor(W, dtype=torch.float32)
    X_t = torch.tensor(X_calib, dtype=torch.float32)
    optimizer = torch.optim.Adam([Cb] + Ce_list, lr=lr)
    for _ in range(steps):
        optimizer.zero_grad()
        # reconstruct quantized weight
        Wq = Cb[B_base]
        for t, Ce in enumerate(Ce_list):
            Wq = Wq + Ce[B_exts[t]]
        diff = (W_t - Wq) @ X_t
        loss = torch.norm(diff) ** 2
        loss.backward()
        optimizer.step()
    return Cb.detach().numpy(), [Ce.detach().numpy() for Ce in Ce_list]


def BeamSearchOptimize(W, C_base, C_exts, B_base, B_exts, X_calib):
    """
    Greedy beam-search to refine code assignments per output row.
    """
    W_t = torch.tensor(W)
    X_t = torch.tensor(X_calib)
    B_base_new = B_base.copy()
    B_exts_new = [b.copy() for b in B_exts]
    out_dim = W.shape[0]
    for i in range(out_dim):
        best_err = float('inf')
        best_b = B_base_new[i]
        best_es = [b[i] for b in B_exts_new]
        # try base codes
        for k in range(C_base.shape[0]):
            wq = torch.tensor(C_base[k])
            for t, Ce in enumerate(C_exts):
                wq = wq + torch.tensor(Ce[B_exts_new[t][i]])
            err = float(torch.norm((W_t[i] - wq) @ X_t) ** 2)
            if err < best_err:
                best_err = err
                best_b = k
        B_base_new[i] = best_b
        # try extended codes
        for t, Ce in enumerate(C_exts):
            for k in range(Ce.shape[0]):
                wq = torch.tensor(C_base[B_base_new[i]])
                for u, Ce2 in enumerate(C_exts):
                    idx = k if u == t else B_exts_new[u][i]
                    wq = wq + torch.tensor(C_exts[u][idx])
                err = float(torch.norm((W_t[i] - wq) @ X_t) ** 2)
                if err < best_err:
                    best_err = err
                    best_es[t] = k
            B_exts_new[t][i] = best_es[t]
    return B_base_new, B_exts_new


def FineTuneBlock(model, block_layers, calib_loader, lr=1e-3, epochs=2):
    """
    Fine-tunes the specified layers (block) on calibration data.
    """
    from torch import nn, optim
    # freeze all
    for p in model.parameters(): p.requires_grad = False
    # unfreeze block
    params = []
    for layer in block_layers:
        for p in layer.parameters(): p.requires_grad = True; params.append(p)
    opt = optim.SGD(params, lr=lr)
    criterion = nn.CrossEntropyLoss()
    model.train()
    for _ in range(epochs):
        for X, y in calib_loader:
            logits = model(X)
            loss = criterion(logits, y)
            opt.zero_grad(); loss.backward(); opt.step()
    # re-freeze
    for p in params: p.requires_grad = False


def E2E_FineTune(model, calib_loader, lr=1e-4, epochs=2):
    """
    End-to-end fine-tuning of the full quantized model.
    """
    from torch import nn, optim
    # unfreeze all
    for p in model.parameters(): p.requires_grad = True
    opt = optim.Adam(model.parameters(), lr=lr)
    criterion = nn.CrossEntropyLoss()
    model.train()
    for _ in range(epochs):
        for X, y in calib_loader:
            logits = model(X)
            loss = criterion(logits, y)
            opt.zero_grad(); loss.backward(); opt.step()
