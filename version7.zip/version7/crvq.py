# -*- coding: utf-8 -*-
"""
crvq.py – orchestrator implementing Algorithm 1.
"""
from __future__ import annotations
import numpy as np, torch, logging
from modules import (partition_to_vectors, reassemble_from_vectors,
                     kmeans_codebook, vector_quantize,
                     importance_metric, reorder_channels, restore_order,
                     beam_search_iterative, compression_ratio)

log = logging.getLogger("crvq")

class CRVQ:
    def __init__(self, d=8, e=8, m=4, lam=0.05, eps=1e-3):
        self.d, self.e, self.m, self.lam, self.eps = d,e,m,lam,eps
        self.state = {}   # per-layer details

    # ------------------------------------------------------------ #
    def quantise_layer(self, name:str, W: torch.Tensor,
                       h_diag: np.ndarray | None = None):
        Wnp = W.detach().cpu().numpy()
        O,I = Wnp.shape

        # Step 3: pre-quant (coarse VQ)
        V, pad = partition_to_vectors(Wnp, self.d)
        C_coarse = kmeans_codebook(V, 2**min(6,self.e))
        Vq,_ = vector_quantize(V, C_coarse)
        Wq_coarse = reassemble_from_vectors(Vq, O,I,pad,self.d)

        # Step 4: importance
        imp = importance_metric(Wnp, Wq_coarse, h_diag)
        # Step 5: reorder
        W_sorted, perm = reorder_channels(Wnp, imp)

        # Step 6–7: base codebook
        V_sorted, pad = partition_to_vectors(W_sorted, self.d)
        C_base = kmeans_codebook(V_sorted, 2**self.e)
        Vq_base, B_base = vector_quantize(V_sorted, C_base)
        C_list=[C_base]; B_list=[B_base]

        # Steps 8–13: extended codebooks on λ fraction
        crit_rows = max(1, int(self.lam * O))
        idx_crit = np.arange(crit_rows*(I//self.d))  # vectors index
        for _ in range(self.m-1):
            resid = V_sorted[idx_crit] - _recon(C_list,B_list)[idx_crit]
            if np.mean(resid**2) < self.eps: break
            C_ext = kmeans_codebook(resid, 2**self.e)
            Vq_ext, B_ext = vector_quantize(resid, C_ext)
            fill_codes = np.zeros_like(B_base)
            fill_codes[idx_crit] = B_ext
            C_list.append(C_ext); B_list.append(fill_codes)

        # Step 16: beam search
        B_list = beam_search_iterative(V_sorted, C_list, B_list,
                                       beam=4, iters=4)

        # Reconstruct & restore order
        V_final = _recon(C_list, B_list)
        Wq_sorted = reassemble_from_vectors(V_final, O,I,pad,self.d)
        Wq = restore_order(Wq_sorted, perm)

        cr, bpp = compression_ratio(O,I,self.d,self.e,len(C_list),self.lam)
        log.info(f\"Layer {name}: compression ≈{cr:.1f}×  ({bpp:.2f} bits/param)\")
        self.state[name] = dict(codebooks=C_list, codes=B_list, perm=perm)
        return torch.tensor(Wq, dtype=W.dtype)

# helper
def _recon(C_list, B_list):  # → vectors
    v = C_list[0][B_list[0]].copy()
    for C,B in zip(C_list[1:], B_list[1:]):
        v += C[B]
    return v
