# -*- coding: utf-8 -*-
"""
modules.py – low-level helpers for CRVQ
--------------------------------------
• partition_to_vectors / reassemble_from_vectors
• k-means codebook + VQ
• Hessian-diag capture for importance (activation hooks)
• beam_search_iterative  (multi-step index refinement)
• compression_ratio  (Eq. 8, CRVQ appendix)
"""
from __future__ import annotations
import logging, numpy as np, torch
from sklearn.cluster import KMeans
from scipy.spatial.distance import cdist

log = logging.getLogger("modules")
log.addHandler(logging.NullHandler())

# --------------------------------------------------------------------- #
# Partition helpers
# --------------------------------------------------------------------- #
def partition_to_vectors(mat: np.ndarray, d: int):
    flat = mat.T.reshape(-1)
    pad = (-len(flat)) % d
    if pad:
        flat = np.concatenate([flat, np.zeros(pad, flat.dtype)])
    return flat.reshape(-1, d), pad

def reassemble_from_vectors(vectors: np.ndarray,
                            O: int, I: int, pad: int, d: int):
    flat = vectors.reshape(-1)
    if pad:
        flat = flat[:-pad]
    return flat.reshape(I, O).T

# --------------------------------------------------------------------- #
# Vector-Quantisation basics
# --------------------------------------------------------------------- #
def kmeans_codebook(vecs: np.ndarray, k: int):
    k_eff = min(k, len(vecs)) or 1
    km = KMeans(n_clusters=k_eff, n_init=6, random_state=0).fit(vecs)
    C = km.cluster_centers_
    if C.shape[0] < k:  # pad if too few
        C = np.vstack([C, np.zeros((k - C.shape[0], C.shape[1]), C.dtype)])
    return C

def vector_quantize(vecs: np.ndarray, C: np.ndarray):
    dist2 = cdist(vecs, C, metric="sqeuclidean")
    codes = dist2.argmin(1).astype(np.int32)
    return C[codes], codes

# --------------------------------------------------------------------- #
# Importance (Eq.7 simplified: max error × Hessian-inv diag)
# --------------------------------------------------------------------- #
def importance_metric(W: np.ndarray, Wq: np.ndarray,
                      h_inv_diag: np.ndarray | None):
    err2 = (W - Wq)**2
    max_err = err2.max(1)
    if h_inv_diag is None or len(h_inv_diag) != len(max_err):
        h_inv_diag = np.ones_like(max_err)
    return 0.5 * max_err * h_inv_diag

def reorder_channels(W: np.ndarray, imp: np.ndarray):
    perm = np.argsort(-imp)
    return W[perm], perm

def restore_order(W_sorted: np.ndarray, perm: np.ndarray):
    inv = np.argsort(perm)
    return W_sorted[inv]

# --------------------------------------------------------------------- #
# Beam search (multi-step)
# --------------------------------------------------------------------- #
def _recon(C_list, B_list):
    v = C_list[0][B_list[0]].copy()
    for C, B in zip(C_list[1:], B_list[1:]):
        v += C[B]
    return v

def beam_search_iterative(vecs, C_list, codes, beam=4, iters=5, tol=1e-4):
    prev = ((vecs - _recon(C_list, codes))**2).sum()
    for _ in range(iters):
        for l, (C, code) in enumerate(zip(C_list, codes)):
            for i in range(len(code)):
                best = code[i]
                best_err = ((vecs[i] - _recon(C_list, codes)[i])**2).sum()
                cand = np.argpartition(((vecs[i] -
                    (_recon(C_list, codes)[i] - C[code[i]] + C))**2).sum(1), beam)[:beam]
                for alt in cand:
                    old = code[i]; code[i] = alt
                    err = ((vecs[i] - _recon(C_list, codes)[i])**2).sum()
                    if err < best_err:
                        best, best_err = alt, err
                    else:
                        code[i] = old
        cur = ((vecs - _recon(C_list, codes))**2).sum()
        if (prev - cur)/(prev+1e-12) < tol:
            break
        prev = cur
    return codes

# --------------------------------------------------------------------- #
# Hessian-diag capture (activation hook)
# --------------------------------------------------------------------- #
def capture_h_inv_diag(model: torch.nn.Module, loader,
                       device="cpu") -> dict[str, np.ndarray]:
    acts = {}
    hooks = []
    def make_hook(name):
        def _hook(_, inp, __):
            x = inp[0].detach().to(device).flatten(0, -2)  # merge batch/seq
            acts[name] = acts.get(name, 0) + x.t() @ x
        return _hook
    for n, m in model.named_modules():
        if isinstance(m, torch.nn.Linear):
            hooks.append(m.register_forward_hook(make_hook(n)))
    model.eval()
    with torch.no_grad():
        for xb, _ in loader:
            model(xb.to(device))
    for h in hooks: h.remove()
    hinv = {}
    for n, H in acts.items():
        diag_inv = torch.diag(torch.inverse(H + 1e-6*torch.eye(H.size(0),
                                  device=device))).cpu().numpy()
        hinv[n] = diag_inv
    return hinv

# --------------------------------------------------------------------- #
# Compression formula  (Eq.8, CRVQ Appendix)
# --------------------------------------------------------------------- #
def compression_ratio(O:int, I:int, d:int, e:int, m:int, lam:float):
    bits_per_weight = (e/d) + ((m-1)*lam*e/d) + ((2**e - 16)/(m*d))
    return 16/bits_per_weight, bits_per_weight
