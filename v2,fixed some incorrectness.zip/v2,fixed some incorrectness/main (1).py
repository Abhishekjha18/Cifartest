import torch, math, os
import numpy as np
from modules import (
    Prequantize, ComputeImportance, ReorderChannels,
    KMeansCodebook, VectorQuant, ComputeError, Update,
    FineTuneCodebook, BeamSearchOptimize, FineTuneBlock,
    E2E_FineTune, reconstruct_weight
)

class CRVQ:
    """Channel‑Relaxed Vector Quantisation orchestrator (FC layers only)."""
    def __init__(self, m=4, lambda_ratio=0.05, e_bit=8, d_dim=8, loss_thr=1e-2):
        self.m = m; self.lambda_ratio = lambda_ratio
        self.e_bit = e_bit; self.d_dim = d_dim; self.loss_thr = loss_thr
        self.hinv = {}
        self.fc_param_count = 0   # for compression stats

    # ---------------------------------------------------------
    # Hessian proxy (XX^T) collection over calibration set
    # ---------------------------------------------------------
    def _collect_hessian_inv(self, model, loader):
        stats={}  # layer→XTX
        for lyr in model.modules():
            if isinstance(lyr, torch.nn.Linear):
                d = lyr.weight.shape[1]
                stats[lyr] = torch.zeros(d, d)
                lyr.register_forward_hook(
                    lambda m, inp, out, key=lyr: stats.__setitem__(key, stats[key] + inp[0].detach().view(-1,d).T @ inp[0].detach().view(-1,d))
                )
        model.eval()
        with torch.no_grad():
            for X,_ in loader: model(X)
        for lyr, mat in stats.items():
            mat += 1e-6*torch.eye(mat.size(0))
            self.hinv[lyr] = torch.linalg.pinv(mat).diag().cpu().numpy()

    # ---------------------------------------------------------
    def quantize_model(self, model, calib_loader):
        self._collect_hessian_inv(model, calib_loader)
        X_calib,_ = next(iter(calib_loader))
        X_calib = X_calib.reshape(-1, X_calib.shape[-1]).T.numpy()  # [in, batch]
        for lyr in model.modules():
            if not isinstance(lyr, torch.nn.Linear):
                continue
            W = lyr.weight.data.cpu().numpy()       # [out,in]
            Hdiag = self.hinv[lyr]
            self.fc_param_count += W.size
            # --- Alg1 L3‑7 ---
            W_pre, _ = Prequantize(W, self.e_bit, self.d_dim)
            imp = ComputeImportance(W, W_pre, Hdiag)
            W_sort, sort_idx = ReorderChannels(W, imp)
            out_dim, in_dim = W_sort.shape
            # base codebook
            pad = (self.d_dim - in_dim%self.d_dim)%self.d_dim
            vecs = np.pad(W_sort.T, ((0,0),(0,pad)), 'constant').reshape(-1,self.d_dim)
            C_base = KMeansCodebook(vecs, self.e_bit)
            Q_base, B_base = VectorQuant(vecs, C_base)
            W_enc = Q_base.reshape(in_dim+pad, out_dim).T[:,:in_dim]
            # --- Extended codebooks ---
            num_crit = max(1, int(in_dim*self.lambda_ratio))
            C_exts, B_exts = [], []
            for _ in range(1,self.m):
                res_vec = (W_sort[:,:num_crit]-W_enc[:,:num_crit]).T.reshape(-1,self.d_dim)
                Cext = KMeansCodebook(res_vec, self.e_bit)
                Qext, Bext = VectorQuant(res_vec, Cext)
                Qext = Qext.reshape(num_crit, out_dim).T
                W_enc[:,:num_crit] = Update(W_enc[:,:num_crit], Qext)
                C_exts.append(Cext); B_exts.append(Bext)
            # --- Fine‑tune centroids & codes (15 & 16) ---
            C_base, C_exts = FineTuneCodebook(C_base, C_exts, W_sort, B_base, B_exts, X_calib)
            B_base, B_exts = BeamSearchOptimize(W_sort, C_base, C_exts, B_base, B_exts, X_calib)
            # --- Reconstruct & copy back ---
            W_q = reconstruct_weight(C_base,C_exts,B_base,B_exts,sort_idx,lyr.weight.shape,lyr.weight.dtype)
            lyr.weight.data.copy_(W_q)
            # --- Block‑level FT (single layer block) ---
            FineTuneBlock(model,[lyr],calib_loader)
        # end for layer
        # --- E2E fine‑tune ---
        E2E_FineTune(model, calib_loader)
        return model

    # stats helpers
    def compression_bits(self, conv_bits, fc_bits):
        return conv_bits*32 + fc_bits*self.e_bit
