import os, logging
logging.basicConfig(level=os.environ.get("LOGLEVEL", "INFO"),
                    format="%(levelname)s %(name)s: %(message)s")

import torch
from torch import nn
from torchvision import datasets, transforms
from torch.utils.data import DataLoader
from crvq_debug import CRVQ

# ------------------------------------------------------------------
# Simple MNIST CNN (conv + 2 FC)
# ------------------------------------------------------------------
class SimpleCNN(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(1, 16, 3, 1), nn.ReLU(), nn.MaxPool2d(2),
            nn.Conv2d(16, 32, 3, 1), nn.ReLU(), nn.MaxPool2d(2),
        )
        self.fc1 = nn.Linear(32 * 5 * 5, 128)
        self.fc2 = nn.Linear(128, 10)

    def forward(self, x):
        x = self.conv(x)
        x = x.flatten(1)
        x = torch.relu(self.fc1(x))
        return self.fc2(x)

# ------------------------------------------------------------------
# Data
# ------------------------------------------------------------------
tfm = transforms.ToTensor()
root = "./data"
val_set = datasets.MNIST(root, train=False, download=True, transform=tfm)
val_ld  = DataLoader(val_set, batch_size=256)
calib_ld= DataLoader(val_set, batch_size=256, shuffle=False)

# ------------------------------------------------------------------
# Load baseline
# ------------------------------------------------------------------
model = SimpleCNN()
model.load_state_dict(torch.load("original_model.pth"))
model.eval()

def accuracy(net):
    net.eval(); tot=0
    with torch.no_grad():
        for xb,yb in val_ld:
            tot += (net(xb).argmax(1)== yb).sum().item()
    return tot/len(val_set)

print(f"Baseline accuracy: {accuracy(model):.4f}")

# ------------------------------------------------------------------
# CRVQ
# ------------------------------------------------------------------
crvq = CRVQ(e=8, m=4, lam=0.05, d=8, eps=1e-2, max_loops=10)
model_q = crvq.quantise(model, calib_ld, ft_loader=calib_ld)
print(f"Quantised accuracy: {accuracy(model_q):.4f}")

fc_bits_orig = sum(p.numel()*32 for n,p in model.named_parameters() if 'fc' in n and 'weight' in n)
fc_bits_q    = sum(p.numel()*8  for n,p in model_q.named_parameters() if 'fc' in n and 'weight' in n)
print(f"Approx FC compression: {fc_bits_orig/fc_bits_q:.2f}×")

torch.save(model_q.state_dict(), "quantized_model.pth")
print("Saved quantized_model.pth")
