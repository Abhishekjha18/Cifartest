# -*- coding: utf-8 -*-
"""
CRVQ helpers  –  verbose/debug version, with **iterative beam-search**.
All functions operate on numpy arrays (CPU) for portability; PyTorch tensors are
converted by the caller when needed.

Logging levels: set `LOGLEVEL=DEBUG` / `INFO` / `WARNING` in the environment.
"""

import logging
import numpy as np
import torch
from sklearn.cluster import KMeans

log = logging.getLogger("CRVQ.modules")
log.addHandler(logging.NullHandler())

# ---------------------------------------------------------------------------
# Partition helpers
# ---------------------------------------------------------------------------

def partition_to_vectors(mat: np.ndarray, d: int):
    """Column‑major flatten then reshape into d‑dimensional vectors."""
    out, inp = mat.shape
    flat = mat.T.reshape(-1)            # column‑major order
    pad_len = (-len(flat)) % d          # 0 ≤ pad_len < d
    if pad_len:
        log.debug(f"Pad {pad_len} zeros so len(flat) % d == 0")
        flat = np.concatenate([flat, np.zeros(pad_len, flat.dtype)])
    vectors = flat.reshape(-1, d)
    log.debug(f"partition: {mat.shape} → {vectors.shape}")
    return vectors, pad_len


def reassemble_from_vectors(vectors: np.ndarray, out_dim: int, in_dim: int,
                            pad_len: int, d: int):
    flat = vectors.reshape(-1)
    if pad_len:
        flat = flat[:-pad_len]
    mat_sorted = flat.reshape(in_dim, out_dim).T
    return mat_sorted

# ---------------------------------------------------------------------------
# Importance & channel reordering (Eq. 7)
# ---------------------------------------------------------------------------

def compute_importance_fc(W: torch.Tensor, Wq: torch.Tensor, h_diag: np.ndarray):
    """Return importance per **column**.
    I_i = 0.5 * max_j (Δw_{ji})² * (XXᵀ)⁻¹_{ii}
    """
    diff2 = (W - Wq).square().cpu().numpy()       # [out, in]
    max_err2 = diff2.max(0)                       # (in,)
    if len(h_diag) != len(max_err2):
        log.warning("Hessian diag len mismatch – fallback to 1s")
        h_diag = np.ones_like(max_err2)
    return 0.5 * max_err2 * h_diag


def reorder_columns(W: torch.Tensor, importance: np.ndarray):
    sort_idx = np.argsort(-importance)            # NEW‑>OLD
    return W[:, sort_idx], sort_idx

# ---------------------------------------------------------------------------
# K‑means codebook + VQ
# ---------------------------------------------------------------------------

def kmeans_codebook(vectors: np.ndarray, k: int):
    """Return exactly k centroids (pad with zeros if necessary)."""
    k_eff = min(k, len(vectors))
    if k_eff < k:
        log.warning("k‑means: fewer points than centroids; centroids will repeat.")
    km = KMeans(n_clusters=k_eff, n_init=5, random_state=0).fit(vectors)
    C = km.cluster_centers_
    if C.shape[0] < k:
        pad = np.zeros((k - C.shape[0], C.shape[1]), dtype=C.dtype)
        C = np.vstack([C, pad])
    log.debug(f"k‑means: centroids {C.shape}")
    return C


def vector_quantize(vectors: np.ndarray, codebook: np.ndarray):
    diff = vectors[:, None, :] - codebook[None, :, :]
    codes = np.argmin((diff ** 2).sum(-1), -1).astype(np.int32)
    return codebook[codes], codes

# ---------------------------------------------------------------------------
# Multi‑step beam search (QuIP / AQLM style)
# ---------------------------------------------------------------------------

def _reconstruct_vectors(codebooks, codes_list):
    vq = codebooks[0][codes_list[0]].copy()
    for C, c in zip(codebooks[1:], codes_list[1:]):
        vq += C[c]
    return vq


def beam_search_once(vectors, codebooks, codes_list, beam=4):
    """A single greedy sweep updating codes layer‑by‑layer."""
    accum = _reconstruct_vectors(codebooks, codes_list)
    for C, code in zip(codebooks, codes_list):
        for i in range(len(code)):
            best = code[i]
            best_err = ((vectors[i] - accum[i])**2).sum()
            cand = np.argpartition(((vectors[i] - (accum[i] - C[code[i]] + C))**2).sum(1), beam)[:beam]
            for alt in cand:
                new_val = accum[i] - C[code[i]] + C[alt]
                e = ((vectors[i] - new_val)**2).sum()
                if e < best_err:
                    accum[i] = new_val
                    best = alt
                    best_err = e
            code[i] = best
    return codes_list


def beam_search_iterative(vectors, codebooks, codes_init,
                          beam=4, max_iter=10, tol=1e-4):
    codes = [c.copy() for c in codes_init]
    prev = ((vectors - _reconstruct_vectors(codebooks, codes))**2).sum()
    for it in range(max_iter):
        codes = beam_search_once(vectors, codebooks, codes, beam)
        cur = ((vectors - _reconstruct_vectors(codebooks, codes))**2).sum()
        rel = (prev - cur) / (prev + 1e-12)
        log.debug(f"  beam iter {it}: loss {cur:.3e}  Δ{rel:.2%}")
        if rel < tol:
            break
        prev = cur
    return codes

# ---------------------------------------------------------------------------
# Loss & fine‑tune helpers (unchanged from previous debug)
# ---------------------------------------------------------------------------

def quant_loss(W, Wq, X=None):
    if X is None:
        return torch.norm(W - Wq).item()
    return torch.norm(W @ X - Wq @ X).item()


def fine_tune_codebooks(C_base, C_exts, vectors_sorted, codes_base, codes_exts,
                        X_cols, lr=1e-3, steps=30):
    """Gradient descent on centroids (codes fixed)."""
    dev = vectors_sorted.device
    Cb = torch.tensor(C_base, device=dev, requires_grad=True)
    Cext = [torch.tensor(C, device=dev, requires_grad=True) for C in C_exts]
    opt = torch.optim.Adam([Cb] + Cext, lr=lr)
    cb_idx = torch.tensor(codes_base, device=dev)
    ext_idx = [torch.tensor(c, device=dev) for c in codes_exts]

    for _ in range(steps):
        opt.zero_grad()
        vq = Cb[cb_idx]
        for Ce, ci in zip(Cext, ext_idx):
            vq += Ce[ci]
        loss = (vq - vectors_sorted).pow(2).mean()
        loss.backward(); opt.step()
    return (Cb.detach().cpu().numpy(),
            [C.detach().cpu().numpy() for C in Cext])


from torch import nn  # after torch import

def fine_tune_block(model, layers, loader, lr=1e-3, epochs=1):
    log.info(" Block‑level fine‑tune …")
    for p in model.parameters():
        p.requires_grad = False
    params = [p for ly in layers for p in ly.parameters()]
    for p in params:
        p.requires_grad = True
    opt = torch.optim.Adam(params, lr=lr)
    ce = nn.CrossEntropyLoss()
    model.train()
    for _ in range(epochs):
        for xb, yb in loader:
            opt.zero_grad(); ce(model(xb), yb).backward(); opt.step()
    for p in model.parameters():
        p.requires_grad = False


def e2e_fine_tune(model, loader, lr=1e-4, epochs=1):
    log.info(" E2E fine‑tune …")
    for p in model.parameters(): p.requires_grad = True
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    ce = nn.CrossEntropyLoss()
    model.train()
    for _ in range(epochs):
        for xb, yb in loader:
            opt.zero_grad(); ce(model(xb), yb).backward(); opt.step()
    model.eval()
