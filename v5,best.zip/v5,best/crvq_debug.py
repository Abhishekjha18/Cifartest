# -*- coding: utf-8 -*-
"""
CRVQ orchestrator – debug version with **iterative fine‑tune + multi‑step beam**
"""

import logging, numpy as np, torch
from torch import nn
from modules_debug import (
    partition_to_vectors, reassemble_from_vectors,
    compute_importance_fc, reorder_columns,
    kmeans_codebook, vector_quantize,
    fine_tune_codebooks, beam_search_iterative,
    quant_loss, fine_tune_block, e2e_fine_tune)

log = logging.getLogger("CRVQ.core")
log.addHandler(logging.NullHandler())

class CRVQ:
    def __init__(self, e=8, m=4, lam=0.05, d=8, eps=1e-2, max_loops=10):
        self.e = e; self.K = 2 ** e
        self.m = m; self.lam = lam
        self.d = d; self.eps = eps; self.max_loops = max_loops
        self.state = {}

    # ------------------------------------------------------------------
    def _capture_hinv(self, model, loader):
        hinv = {}; hooks = []
        def mk(n):
            def _hook(_, inp, __):
                x = inp[0].detach().flatten(0,-2)
                hinv[n] = hinv.get(n,0) + x.t() @ x
            return _hook
        for n,m in model.named_modules():
            if isinstance(m, nn.Linear):
                hooks.append(m.register_forward_hook(mk(n)))
        model.eval();
        with torch.no_grad():
            for xb,_ in loader: model(xb)
        for h in hooks: h.remove()
        return {n: torch.diag(torch.inverse(H+1e-6*torch.eye(H.size(0)))).cpu().numpy()
                for n,H in hinv.items()}

    # ------------------------------------------------------------------
    def quantise(self, model, calib_loader, ft_loader=None):
        hdiag_inv = self._capture_hinv(model, calib_loader)
        for name, lyr in model.named_modules():
            if not isinstance(lyr, nn.Linear):
                continue
            W = lyr.weight.data.clone(); out_dim, in_dim = W.shape
            log.info(f"[{name}] out={out_dim} in={in_dim}")

            # pre‑quant → importance
            v_pre, pad_pre = partition_to_vectors(W.cpu().numpy(), self.d)
            C_pre = kmeans_codebook(v_pre, self.K)
            vq_pre,_ = vector_quantize(v_pre, C_pre)
            Wq_pre = torch.tensor(reassemble_from_vectors(vq_pre, out_dim, in_dim,
                                                          pad_pre, self.d), dtype=W.dtype)
            imp = compute_importance_fc(W, Wq_pre, hdiag_inv[name])
            W_s, perm = reorder_columns(W, imp)

            # base codebook
            v_s, pad = partition_to_vectors(W_s.cpu().numpy(), self.d)
            C_base = kmeans_codebook(v_s, self.K)
            vq_s, codes_base = vector_quantize(v_s, C_base)
            Wenc = torch.tensor(reassemble_from_vectors(vq_s, out_dim, in_dim,
                                                        pad, self.d), dtype=W.dtype)
            # additive codebooks
            crit = max(1, int(self.lam*in_dim))
            C_ext, codes_ext = [], []
            for _ in range(self.m-1):
                resid = (W_s[:,:crit]-Wenc[:,:crit]).cpu().numpy()
                vr, p_r = partition_to_vectors(resid, self.d)
                Ce = kmeans_codebook(vr, self.K)
                vqe, ce = vector_quantize(vr, Ce)
                Wenc[:,:crit] += torch.tensor(reassemble_from_vectors(vqe, out_dim, crit,
                                                                       p_r, self.d), dtype=W.dtype)
                C_ext.append(Ce); codes_ext.append(ce)

            # iterative FT + beam
            vec_np = v_s
            loss_prev = quant_loss(W_s, Wenc)
            log.info(f"  init loss={loss_prev:.3e}")
            for loop in range(self.max_loops):
                C_base, C_ext = fine_tune_codebooks(C_base, C_ext, torch.tensor(vec_np),
                                                    codes_base, codes_ext, None)
                codes_all = beam_search_iterative(vec_np, [C_base]+C_ext,
                                                  [codes_base]+codes_ext,
                                                  beam=4, max_iter=5)
                codes_base, codes_ext = codes_all[0], codes_all[1:]
                v_all = C_base[codes_base]
                for Ce, ce in zip(C_ext, codes_ext):
                    v_all += Ce[ce]
                Wenc = torch.tensor(reassemble_from_vectors(v_all, out_dim, in_dim,
                                                             pad, self.d), dtype=W.dtype)
                loss = quant_loss(W_s, Wenc)
                rel = (loss_prev-loss)/(loss_prev+1e-12)
                log.info(f"    iter {loop}: loss {loss:.3e}  Δ{rel:.2%}")
                if rel < 1e-3 or loss < self.eps: break
                loss_prev = loss

            # restore original column order
            Wq_np = reassemble_from_vectors(v_all, out_dim, in_dim, pad, self.d)
            W_final = torch.tensor(Wq_np[:, np.argsort(perm)], dtype=W.dtype)
            lyr.weight.data.copy_(W_final)
            self.state[name] = dict(C_base=C_base, C_ext=C_ext,
                                    codes_base=codes_base, codes_ext=codes_ext,
                                    perm=perm)

        # optional FT
        if ft_loader is not None:
            fc = [m for m in model.modules() if isinstance(m, nn.Linear)]
            fine_tune_block(model, fc, ft_loader, epochs=1)
            e2e_fine_tune(model, ft_loader, epochs=1)
        return model
