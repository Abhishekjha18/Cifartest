# --- modules_debug.py ---
import numpy as np
from sklearn.cluster import KMeans
import logging

log = logging.getLogger("CRVQ.modules")
log.addHandler(logging.NullHandler())

# Helper: Partition weight matrix into d-dim vectors
def partition_to_vectors(W: np.ndarray, d: int):
    V = W.flatten()
    pad = (d - len(V) % d) % d
    if pad: V = np.pad(V, (0, pad))
    return V.reshape(-1, d), pad

# Helper: Reconstruct weight matrix from vectors
def reassemble_from_vectors(V: np.ndarray, O: int, I: int, pad: int, d: int):
    flat = V.flatten()[:-pad] if pad else V.flatten()
    return flat.reshape(O, I)

# KMeans Codebook Generation
def kmeans_codebook(vectors: np.ndarray, n_clusters: int):
    if len(vectors) < n_clusters:
        n_clusters = max(1, len(vectors))
    kmeans = KMeans(n_clusters=n_clusters, n_init='auto', random_state=0)
    kmeans.fit(vectors)
    return kmeans.cluster_centers_

# Vector Quantization
def vector_quantize(vectors: np.ndarray, codebook: np.ndarray):
    dist = ((vectors[:, None] - codebook[None]) ** 2).sum(-1)
    codes = dist.argmin(1)
    return codebook[codes], codes

# Beam Search
def beam_search_iterative(V, C_list, B_init_list, beam=4):
    log.info("[BeamSearch] Starting beam search optimization...")
    from copy import deepcopy
    V_best = _recon(C_list, B_init_list)
    loss_best = ((V - V_best) ** 2).mean()
    for _ in range(3):
        for i in range(1, len(C_list)):
            C = C_list[i]
            scores = []
            for j in range(len(C)):
                B_try = deepcopy(B_init_list)
                B_try[i] = np.full_like(B_try[i], j)
                V_try = _recon(C_list, B_try)
                err = ((V - V_try) ** 2).mean()
                scores.append((err, j))
            scores.sort()
            best_j = scores[0][1]
            B_init_list[i] = np.full_like(B_init_list[i], best_j)
            V_best = _recon(C_list, B_init_list)
            loss_best = ((V - V_best) ** 2).mean()
    return B_init_list

def _recon(C_list, B_list):
    v = C_list[0][B_list[0]].copy()
    for Ci, Bi in zip(C_list[1:], B_list[1:]):
        v += Ci[Bi]
    return v

# Importance score from quant error & hessian
import torch

def compute_importance_fc(W, Wq, h_diag=None):
    err = (W - Wq).pow(2)
    imp = err.max(0).values
    if h_diag is not None:
        h_diag = torch.tensor(h_diag[:len(imp)], dtype=W.dtype, device=W.device)
        imp *= h_diag
    return imp

# Reorder channels

def reorder_columns(W, importance):
    idx = torch.argsort(importance, descending=True)
    W_sorted = W[:, idx]
    return W_sorted, idx

# Compression calculator

def compute_crvq_compression(O, I, d, e, m, lam):
    orig_bits = 32 * O * I
    n_code = 2 ** e
    entries = (O * I) // d
    n_crit = int(lam * I)
    base_bits = n_code * d * 32 + entries * e
    ext_bits = (m - 1) * (n_code * d * 32 + entries * e * lam)
    total_bits = base_bits + ext_bits
    return orig_bits / total_bits, total_bits / (O * I)
