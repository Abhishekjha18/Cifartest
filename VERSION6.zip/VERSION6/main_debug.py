# --- main_debug.py ---
import torch
import torch.nn as nn
import torch.optim as optim
from torchvision import datasets, transforms
from crvq_debug import crvq_fc_layer
import os, logging

os.environ["LOGLEVEL"] = "INFO"
logging.basicConfig(level=os.environ["LOGLEVEL"])
log = logging.getLogger("CRVQ.main")

class SimpleFCNet(nn.Module):
    def __init__(self):
        super().__init__()
        self.fc1 = nn.Linear(784, 256)
        self.relu = nn.ReLU()
        self.fc2 = nn.Linear(256, 10)

    def forward(self, x):
        x = x.view(-1, 784)
        x = self.relu(self.fc1(x))
        x = self.fc2(x)
        return x

def train_model(model, train_loader, epochs=3):
    model.train()
    optimizer = optim.Adam(model.parameters(), lr=1e-3)
    loss_fn = nn.CrossEntropyLoss()
    for epoch in range(epochs):
        total = 0
        for x, y in train_loader:
            optimizer.zero_grad()
            loss = loss_fn(model(x), y)
            loss.backward()
            optimizer.step()
            total += loss.item()
        log.info(f"[Train] Epoch {epoch+1}: Loss {total / len(train_loader):.4f}")

def test_model(model, test_loader):
    model.eval()
    correct = 0
    total = 0
    with torch.no_grad():
        for x, y in test_loader:
            pred = model(x).argmax(1)
            correct += (pred == y).sum().item()
            total += y.size(0)
    acc = 100. * correct / total
    log.info(f"[Eval] Accuracy: {acc:.2f}%")
    return acc

def main():
    transform = transforms.ToTensor()
    train_loader = torch.utils.data.DataLoader(
        datasets.MNIST("./data", train=True, download=True, transform=transform),
        batch_size=128, shuffle=True)
    test_loader = torch.utils.data.DataLoader(
        datasets.MNIST("./data", train=False, transform=transform),
        batch_size=256)

    model = SimpleFCNet()
    train_model(model, train_loader)
    torch.save(model.state_dict(), "original_model.pth")
    acc_orig = test_model(model, test_loader)

    # Apply CRVQ to fc1
    W = model.fc1.weight.data.clone()
    Wq, cr = crvq_fc_layer(W, d=8, e=6, m=3, lam=0.2)

    model.fc1.weight.data = Wq
    torch.save(model.state_dict(), "crvq_quantized_model.pth")
    acc_final = test_model(model, test_loader)

    log.info(f"[Result] Original Acc: {acc_orig:.2f}%, Post-CRVQ Acc: {acc_final:.2f}%")

if __name__ == "__main__":
    main()
