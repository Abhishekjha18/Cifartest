# --- crvq_debug.py ---
import torch
import numpy as np
import logging
from modules_debug import partition_to_vectors, reassemble_from_vectors, kmeans_codebook, vector_quantize, compute_importance_fc, reorder_columns, beam_search_iterative, compute_crvq_compression

log = logging.getLogger("CRVQ.core")
log.addHandler(logging.NullHandler())

def crvq_fc_layer(W: torch.Tensor, d=8, e=6, m=3, lam=0.2):
    log.info("[CRVQ] Starting CRVQ quantization on weight matrix")
    O, I = W.shape
    V, pad = partition_to_vectors(W, d)
    Wq = W * 0.5  # Dummy prequant
    imp = compute_importance_fc(W, Wq)
    W_sorted, idx = reorder_columns(W, imp)
    V_sorted, pad = partition_to_vectors(W_sorted, d)

    n_crit = int(lam * I)
    V1 = V_sorted[:, :]

    # Step 6-7: Base codebook
    Cbase = kmeans_codebook(V1, 2 ** e)
    Vq_base, Bbase = vector_quantize(V1, Cbase)
    C_list = [Cbase]
    B_list = [Bbase]

    # Steps 8-13: extended codebooks
    for _ in range(m - 1):
        R = V1 - _recon(C_list, B_list)
        Cext = kmeans_codebook(R, 2 ** e)
        Vq_ext, Bext = vector_quantize(R, Cext)
        C_list.append(Cext)
        B_list.append(Bext)

    # Steps 15-16: Multi-step beam search (optional loop)
    B_list = beam_search_iterative(V1, C_list, B_list)
    V_final = _recon(C_list, B_list)
    W_final = reassemble_from_vectors(V_final, O, I, pad, d)
    W_final = torch.tensor(W_final, dtype=W.dtype, device=W.device)

    # Compression info
    cr, bpp = compute_crvq_compression(O, I, d, e, m, lam)
    log.info(f"[CRVQ] Compression Ratio: {cr:.2f}x ({bpp:.2f} bits/param)")
    return W_final, cr

def _recon(C_list, B_list):
    return C_list[0][B_list[0]] + sum(C[B] for C, B in zip(C_list[1:], B_list[1:]))
